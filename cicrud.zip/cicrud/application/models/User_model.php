<?php
class User_model extends CI_model
{
	public  function create($formArray){

		$this->db->insert("users",$formArray);
	}

	 public function all(){
	    $this->db->select('*');
		$this->db->from('users');
	    $query= $this->db->get();
		return $query->result();
	}
     
	public function deleteuser($id)
      {
       $this->db->where('id', $id);
       $this->db->delete('users'); 
     }
  

 //    public function getuserdetail($id){
	// 	$ret=$this->db->select('name,email')
	// 	              ->where('id',$id)
	// 	              ->get('users');
	// 	        return $ret->row();
	// }


	public function update_getuserdetail($id,$updateArray)
	{
		$this->db->where('id',$id);
		$this->db->update('users',$updateArray);
	}
     


	
}
?>