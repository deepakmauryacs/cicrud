<!DOCTYPE html>
<html>
<head>
	<title>Crud Application-user list</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assetes/css/bootstrap.min.css">

</head>
<body>
<nav class="navbar navbar-dark bg-primary">
 <div class="container">
  <div class="row">
    <div class="col-md-6">
  <span class="navbar-brand mb-0 h1">CRUD APPLICATION</span>
</div>
</div>
</div>
</nav>

 <div class="container">
  <div class="row">
    <div class="col-md-9">
    <div style="margin:10px 0px 20px 0px;">
    <H3>User List</H3>
  <a href="<?php echo base_url();  ?>/user/create" type="button" class="btn btn-success">Add  </a>
    <hr>
      <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr>
                          <th> S.No </th>
                          <th> Name</th>
                          <th> Email</th>
                          <th> Action </th>
                          </tr>
                        </thead>
                         <?php  
                             $i=1;
                          foreach ($h as $row)  
                             {  
                               ?>
                        <tbody>
                          <tr>
                            <td>
                             <?php echo $i++;?>
                           </td>
                            <td><?php echo $row->name;?></td>
                            <td>
                              <?php echo $row->email;?>
                            </td>
                            <td>
                               <button type="button" class="btn btn-info" data-toggle="modal" data-target="#exampleModal<?=$row->id?>">Edit</button>
                              
                              <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?=$row->id?>">
                                  View
                               </button>
                             
<!-- Modal -->
<div class="modal fade" id="exampleModal1<?=$row->id?>" abindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">User</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                    
                      <div class="form-group">
                        <label for="exampleInputName1">Name</label>
                        <input type="data" name="name" class="form-control" id="exampleInputName1"  value="<?php echo $row->name; ?>">
                      </div>
                      
                  
                      
                      <div class="form-group">
                        <label for="exampleTextarea1">Email</label>
                        <input type="data" name="email" class="form-control" id="exampleInputName1"  value="<?php echo $row->email; ?>">
                      </div>
               
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>



                               <a type="button" href="<?php echo base_url().'User/delete_row/'.$row->id  ?>" class="btn btn-danger">Delete</a>
                       
                            <td>
                          </tr>
                         
                 



            <!-- Modal -->
<div class="modal fade" id="exampleModal<?=$row->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <form action="<?php echo base_url('User/update_user');?>" method="POST" class="forms-sample">
                      <div class="form-group">
                        <label for="exampleInputName1">Name</label>
                        <input type="data" name="name" class="form-control" id="exampleInputName1"  value="<?php echo $row->name; ?>">
                        <input type="hidden" name="id" value="<?=$row->id?>">
                       <?php echo form_error('name', '<div class="error">', '</div>'); ?>
                      </div>
                      
                  
                      
                      <div class="form-group">
                        <label for="exampleTextarea1">Email</label>
                        <input type="data" name="email" class="form-control" id="exampleInputName1"  value="<?php echo $row->email; ?>">
                        <?php echo form_error('email', '<div class="error">', '</div>'); ?>
                      </div>
                      
                      <button type="submit" class="btn btn-success">Submit</button>
                      <button class="btn btn-primary" data-dismiss="modal">Cancel</button>
                    </form>

      </div>
      <div class="modal-footer">

      </div>
    </div>
  </div>
</div>

                       <?php
                         }
?>

                           
                        </tbody>
                      </table>
    </div>
 
</div>
</div>
</div>




 <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
</body>
</html>