<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
 
    function __construct()
	{
		parent::__construct();
		$this->load->model('User_model');
	}

    public function index(){
  	// $this->load->model('User_model');
  
        $data['h']=$this->User_model->all();
        $this->load->view('list',$data);
    
  }

     public function create() {
     // $this->load->model('User_model');

    $this->form_validation->set_rules('name', 'Name', 'trim|required');
    $this->form_validation->set_rules('email', 'Email', 'required');

    if ($this->form_validation->run() == FALSE) {

    	$this->load->view('create');


    }else{

    	$formArray= array();
    	$formArray['name']=$this->input->post('name');
        $formArray['email']=$this->input->post('email');
        $formArray['creted_at']=date('y-m-d');
        $this->User_model->create($formArray);
        // $this->session->set_flashdate('success','data inserted');
        redirect(base_url().'user/index');



    }
   	
  }
        public function delete_row($id)
         {
         $this->load->model('User_model');
         $this->User_model->deleteuser($id);
         redirect(base_url().'user/index');

         }

        //  // for particular recod
        // public function getdetails($id)
        // {
        //  //loading model
        //    $this->load->model('User_model');
        //    $reslt=$this->User_model->getuserdetail($id);
        //    // Passing Values to update view
        //    redirect('user',['row'=>$reslt]);
        // }


        public function update_user()
        {
           $id = $this->input->post('id');
           $this->form_validation->set_rules('name', 'Name', 'trim|required');
           $this->form_validation->set_rules('email', 'Email', 'required');

          if($this->form_validation->run())
          {
            $this->load->model('User_model');

            $name = $this->input->post('name');
            $email = $this->input->post('email');
            $updateArray = array('name'=>$name,'email'=>$email);
            $this->User_model->update_getuserdetail($id,$updateArray);
            $this->session->set_flashdata('success','Your details has been updated');
            redirect(base_url().'user/index');
          }
          else
          {

          }
            $name = $this->input->post('name');
           $email = $this->input->post('email');

        }
}
?>